"""CR 602/605, 302.6, 702.10 schedules; no engine output is read.

Literal costs: Cavalry 1R, Elf G, Druid 1G, Cub 1G, Invoker 2GG,
Shivan 4RR. Activations: Cavalry tap/target, Shivan R/+1 power,
Invoker 8/target/+5/+5 trample. Empty combat is always explicit.
"""
import copy
import json
from pathlib import Path
from author_priority import author
ROOT=Path(__file__).resolve().parents[2]


def make(name):
    c=author(0,False);c['id']=name;c['play']=[]
    tops=[['0/mountain/'+str(i) for i in range(3)]+['0/axgard-cavalry/0','0/axgard-cavalry/1','0/shivan-dragon/0']+['0/mountain/'+str(i) for i in range(3,10)],
          ['1/forest/'+str(i) for i in range(3)]+['1/llanowar-elves/0','1/bear-cub/0','1/druid-of-the-cowl/0','1/wildheart-invoker/0']+['1/forest/3','1/forest/4','1/llanowar-elves/1','1/druid-of-the-cowl/1']+['1/forest/'+str(i) for i in range(5,10)]]
    # Green needs its sixth land by turn 12. For haste, the two newly cast
    # mana creatures are drawn by turn 10; all other cases draw lands first.
    if name!='haste':
        tops[1]=tops[1][:7]+['1/forest/'+str(i) for i in range(3,10)]+['1/llanowar-elves/1','1/druid-of-the-cowl/1']
    for seat,top in enumerate(tops):
        c['chance'][seat]['after']=top+[x for x in c['decks'][seat]['occurrences'] if x not in top]
    final=10 if name=='haste' else 12 if name.startswith('invoker') else 13
    def e(t,a,k,source=None,inc=None,color=None,step='precombat_main'):
        c['play'].append(dict(sequence=len(c['play']),turn=t,step=step,actor=a,kind=k,source=source,incarnation=inc,color=color))
    def passes(t,a,step='precombat_main'):e(t,a,'pass',step=step);e(t,1-a,'pass',step=step)
    def cast(t,a,card,cost):
        e(t,a,'cast',f'{a}/{card}',1)
        for i in range(cost):e(t,a,'tap_mana',f'{a}/'+('mountain' if a==0 else 'forest')+f'/{i}',2)
        for _ in range(cost):e(t,a,'pay',color=3 if a==0 else 4)
        e(t,a,'finish_payment');passes(t,a)
    def activate(t,a,source,target=None):
        e(t,a,'activate',source,3)
        if target:e(t,a,'activation_target',target,3)
    for t in range(1,final+1):
        a=0 if t%2 else 1;n=(t-1)//2
        passes(t,a,'upkeep')
        if t!=1:passes(t,a,'draw')
        e(t,a,'play_land',f'{a}/'+('mountain' if a==0 else 'forest')+f'/{n}',1)
        if t==2:cast(t,1,'llanowar-elves/0',1)
        if t==3:cast(t,0,'axgard-cavalry/0',2)
        if t==4:cast(t,1,'bear-cub/0',2)
        if t==5:cast(t,0,'axgard-cavalry/1',2)
        if t==6:cast(t,1,'druid-of-the-cowl/0',2)
        if t==8:cast(t,1,'wildheart-invoker/0',4)
        if t==11:cast(t,0,'shivan-dragon/0',6)
        if t==final:
            if name=='haste':
                # Three distinct lands pay the two spells; no default sources.
                for card,lands in [('llanowar-elves/1',[0]),('druid-of-the-cowl/1',[1,2])]:
                    e(t,1,'cast','1/'+card,1)
                    for i in lands:e(t,1,'tap_mana',f'1/forest/{i}',2)
                    for _ in lands:e(t,1,'pay',color=4)
                    e(t,1,'finish_payment');passes(t,1)
                for i,target in enumerate(['1/llanowar-elves/1','1/druid-of-the-cowl/1']):
                    e(t,1,'pass');activate(t,0,f'0/axgard-cavalry/{i}',target)
                    e(t,0,'finish_activation');passes(t,0)
                    e(t,1,'tap_mana',target,3)
            elif name.startswith('invoker'):
                sources=[(f'1/forest/{i}',2) for i in range(6)]+[('1/llanowar-elves/0',3),('1/druid-of-the-cowl/0',3)]
                if name.endswith('floating'):
                    for s,inc in sources:e(t,1,'tap_mana',s,inc)
                activate(t,1,'1/wildheart-invoker/0','1/bear-cub/0')
                if not name.endswith('floating'):
                    for s,inc in sources:e(t,1,'tap_mana',s,inc)
                for _ in range(8):e(t,1,'activation_pay',color=4)
                e(t,1,'finish_activation');passes(t,1)
            else:
                count=2 if name=='shivan-repeated' else 1
                for i in range(count):
                    activate(t,0,'0/shivan-dragon/0')
                    e(t,0,'tap_mana',f'0/mountain/{i}',2)
                    e(t,0,'activation_pay',color=3);e(t,0,'finish_activation')
                for _ in range(count):passes(t,0)
            break
        passes(t,a)
        passes(t,a,'begin_combat');e(t,a,'empty_attackers',step='declare_attackers');passes(t,a,'declare_attackers')
        for step in ('end_combat','postcombat_main','end_turn'):passes(t,a,step)
    c['stop']='activations/'+name
    return c


def fixtures():
    return dict(schema_version=5,family='activations',pins=json.loads((ROOT/'fixtures/reference/full-pool-priority.json').read_text())['pins'],cases=[make(n) for n in ('shivan-single','shivan-repeated','invoker-empty','invoker-floating','haste')])

if __name__=='__main__':
    (ROOT/'fixtures/reference/full-pool-activations.json').write_text(json.dumps(fixtures(),indent=2)+'\n')
