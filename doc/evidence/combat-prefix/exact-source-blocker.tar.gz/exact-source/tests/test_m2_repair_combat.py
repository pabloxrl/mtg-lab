"""Real normal-reset combat client, rules ledgers, and comparator controls."""
from pathlib import Path
import copy
import json
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import played_combat_reference as combat

class CombatTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder=tempfile.TemporaryDirectory()
        cls.actual=combat.native(Path(cls.folder.name))
        cls.doc=json.loads(combat.FIXTURE.read_text())
    @classmethod
    def tearDownClass(cls):cls.folder.cleanup()
    def test_played_client_reaches_combat_damage(self):
        combat.check_run(self.actual,self.doc,'native')
        self.assertTrue(self.actual['checkpoints'])
        for points in self.actual['checkpoints'].values():
            self.assertTrue(points)
            self.assertEqual(points[-1]['step'],'combat_damage')
    def test_early_life_mutation(self):
        bad=copy.deepcopy(self.actual)
        bad['runs']['shivan-unblocked']['points'][0]['life'][0]=19
        bad['checkpoints']['shivan-unblocked'][0]['life'][0]=19
        with self.assertRaisesRegex(ValueError,'life'):
            combat.check_run(bad,self.doc,'native')
    def test_fixture_authoring_is_independent_and_reproducible(self):
        sys.path.insert(0,str(combat.ROOT/'fixtures/reference'))
        import author_combat
        self.assertEqual(author_combat.fixtures(),self.doc)
        self.assertEqual(author_combat.negatives(self.doc),combat.negative_inputs(self.doc))
    def test_comparator_controls(self):
        controls=combat.comparator_controls(self.actual,self.doc,'native')
        self.assertGreaterEqual(len(controls),12)
    def test_simultaneous_marks_and_source_incarnations(self):
        for run in self.actual['runs'].values():self.assertEqual(len(run['marked']),1)
    def test_ordered_graveyard_comparator_retains_real_disagreement(self):
        # Diagnostic regression, not an acceptance waiver: the real full-family
        # runner must still fail on this unexplained/uncontrolled ordered state.
        saved=json.loads((combat.ROOT/'doc/evidence/combat-prefix/ordered-graveyard-checkpoints.json').read_text())
        difference=combat.base.instant_reference.difference(combat.semantic(saved['native']),combat.semantic(saved['xmage']))
        self.assertEqual(difference,dict(path='$.graveyard[1][0]',expected='1/magnigoth-sentry/0',actual='1/thornweald-archer/0'))
    def test_negative_controls_have_exact_consumption_boundaries(self):
        self.assertGreaterEqual(len(self.actual['rejections']),20)
        combat.check_rejections(self.actual,'native')

if __name__=='__main__':unittest.main()
