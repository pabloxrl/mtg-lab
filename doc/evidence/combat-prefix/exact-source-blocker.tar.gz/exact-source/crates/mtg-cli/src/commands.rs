//! Thin unattended clients of existing replay, recorder and comparator contracts.
use crate::simulate;
use mtg_core::{objects::Seat, opening::replay};
use serde_json::{Value, json};
use std::{
    ffi::OsString,
    fs::{self, OpenOptions},
    io::{self, Read, Write},
    path::Path,
    process::{Command, Stdio},
    sync::atomic::{AtomicUsize, Ordering},
    thread,
    time::{Duration, Instant},
};
type Error = (i32, String);
const INPUT_LIMIT: usize = 16 * 1024 * 1024;
const USAGE: &str = "usage: mtg replay verify FILE | replay inspect FILE --seat 0|1 --format jsonl | trajectories validate FILE | conformance --suite checkpoints-v1 --fixture FILE --actual FILE --artifacts NEW_DIR | bench --workload scalar-pass-v1|native-rollout-v1|scalar-windows-v1|scalar-full-pool-v1|scalar-four-modes-v1|scalar-resident-v1 --config FILE; optional trailing --output NEW_FILE; unsupported suites/references fail";
fn invalid(message: impl Into<String>) -> Error {
    (2, message.into())
}
fn io_error(e: impl std::fmt::Display) -> Error {
    (3, e.to_string())
}
fn read(path: &std::ffi::OsStr, limit: usize) -> Result<Vec<u8>, Error> {
    let meta = fs::metadata(path).map_err(|e| invalid(format!("input: {e}")))?;
    if !meta.is_file() || meta.len() > limit as u64 {
        return Err(invalid(
            "input must be a regular file within the byte limit",
        ));
    }
    let mut bytes = Vec::new();
    fs::File::open(path)
        .map_err(|e| invalid(format!("input: {e}")))?
        .take(limit as u64 + 1)
        .read_to_end(&mut bytes)
        .map_err(|e| invalid(format!("input: {e}")))?;
    if bytes.len() > limit {
        return Err(invalid("input exceeds byte limit"));
    }
    Ok(bytes)
}
fn stopped(signal: &AtomicUsize) -> Option<simulate::Stop> {
    match signal.load(Ordering::Relaxed) {
        n if n == signal_hook::consts::SIGTERM as usize => Some(simulate::Stop::Sigterm),
        n if n == signal_hook::consts::SIGINT as usize => Some(simulate::Stop::Sigint),
        _ => None,
    }
}
fn replay_error(e: replay::ReplayError) -> Error {
    // Both verification and inspection are ordinary output surfaces. Core errors
    // may contain private checkpoints, field paths, seeds and semantic payloads.
    let kind = match e {
        replay::ReplayError::Divergence { .. } => "Divergence",
        replay::ReplayError::MissingChoice { .. } => "MissingChoice",
        replay::ReplayError::UnconsumedChoice { .. } => "UnconsumedChoice",
        replay::ReplayError::InvalidChoice { .. } => "InvalidChoice",
        replay::ReplayError::Incompatible { .. } => "Incompatible",
        replay::ReplayError::InvalidConfig(_) => "InvalidConfig",
        replay::ReplayError::Storage(_) => "Storage",
        replay::ReplayError::Malformed => "Malformed",
        replay::ReplayError::Turn(_) => "Turn",
        replay::ReplayError::SemanticChoice { .. } => "SemanticChoice",
    };
    invalid(format!("replay {kind}; privileged detail withheld"))
}
#[derive(serde::Deserialize)]
struct ReplayHeader {
    format: String,
    version: u32,
}
fn replay_command(path: &std::ffi::OsStr, inspect: bool, seat: Seat) -> Result<Value, Error> {
    // Explicit local path access is deliberate privileged input access, not a
    // registry grant. Keep the existing byte bound; never print the path/errors.
    let bytes = read(path, INPUT_LIMIT).map_err(|_| {
        invalid("replay input must be a readable regular file within the byte limit")
    })?;
    // Deserialize directly from bytes: duplicate discriminators are errors, not
    // last-key-wins Value normalization. Never retry another format on failure.
    let header: ReplayHeader =
        serde_json::from_slice(&bytes).map_err(|_| replay_error(replay::ReplayError::Malformed))?;
    match (header.format.as_str(), header.version) {
        ("mtg-core-opening-replay", replay::REPLAY_VERSION) => {
            let game = replay::verify(&bytes).map_err(replay_error)?;
            if inspect {
                let view = game
                    .observe(seat)
                    .map_err(|_| invalid("replay observation unavailable"))?;
                Ok(
                    json!({"type":"replay_inspection","scope":"opening-v1","checkpoint":"final","observation":view}),
                )
            } else {
                Ok(json!({"type":"replay_verification","status":"verified","scope":"opening-v1"}))
            }
        }
        ("mtg-core-played-replay", replay::played::VERSION) => {
            if inspect {
                return Err(invalid("replay inspection supports opening-v1 only"));
            }
            let game = replay::played::verify(&bytes).map_err(replay_error)?;
            Ok(
                json!({"type":"replay_verification","status":"verified","scope":"played-v1",
                "checkpoint":"terminal","life":game.life(),"outcome":game.outcome()}),
            )
        }
        _ => Err(replay_error(replay::ReplayError::Incompatible {
            field: "format/version".into(),
        })),
    }
}
pub fn execute(args: &[OsString], signal: &AtomicUsize) -> Result<i32, Error> {
    let (args, output) = if args.len() >= 2 && args[args.len() - 2] == "--output" {
        (&args[..args.len() - 2], Some(&args[args.len() - 1]))
    } else {
        (args, None)
    };
    let is = |i: usize, value: &str| args.get(i).is_some_and(|s| s == value);
    let (code, mut value) = if is(0, "replay") && (is(1, "verify") || is(1, "inspect")) {
        let inspect = is(1, "inspect");
        if (!inspect && args.len() != 3)
            || (inspect
                && (args.len() != 7 || !is(3, "--seat") || !is(5, "--format") || !is(6, "jsonl")))
        {
            return Err(invalid(USAGE));
        }
        let seat = if inspect {
            match args[4].to_str() {
                Some("0") => Seat::P0,
                Some("1") => Seat::P1,
                _ => return Err(invalid("seat must be 0 or 1")),
            }
        } else {
            Seat::P0
        };
        let value = replay_command(&args[2], inspect, seat)?;
        (0, value)
    } else if is(0, "trajectories") && is(1, "validate") {
        (0, crate::trajectories::validate(&args[2..])?)
    } else if args.len() == 5
        && is(0, "bench")
        && is(1, "--workload")
        && is(2, "scalar-resident-v1")
        && is(3, "--config")
    {
        crate::resident::run(&read(&args[4], 1_048_576)?, signal)?
    } else if args.len() == 5
        && is(0, "bench")
        && is(1, "--workload")
        && (is(2, "scalar-windows-v1")
            || is(2, "scalar-full-pool-v1")
            || is(2, "scalar-four-modes-v1"))
        && is(3, "--config")
    {
        let bytes = read(&args[4], 1_048_576)?;
        let config: Value = serde_json::from_slice(&bytes).map_err(|e| (2, e.to_string()))?;
        if config["workload"].as_str() != args[2].to_str() {
            return Err((2, "workload argument/config mismatch".into()));
        }
        crate::benchmark::run(&bytes, signal)?
    } else if args.len() == 5
        && is(0, "bench")
        && is(1, "--workload")
        && (is(2, "scalar-pass-v1") || is(2, "native-rollout-v1"))
        && is(3, "--config")
    {
        benchmark(&args[4], signal, is(2, "native-rollout-v1"))?
    } else if args.len() == 9
        && is(0, "conformance")
        && is(1, "--suite")
        && is(2, "checkpoints-v1")
        && is(3, "--fixture")
        && is(5, "--actual")
        && is(7, "--artifacts")
    {
        conformance(&args[4], &args[6], &args[8], signal)?
    } else {
        return Err(invalid(USAGE));
    };
    // Versioned command reports own their schema; the envelope supplies v1
    // only for legacy clients that do not declare one themselves.
    if value.get("schema_version").is_none() {
        value["schema_version"] = json!(1);
    }
    let mut sink: Box<dyn Write> = match output {
        Some(path) => Box::new(
            OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(path)
                .map_err(|e| {
                    if is(0, "trajectories") {
                        io_error("trajectory output failure; private detail withheld")
                    } else {
                        io_error(format!("output: {e}"))
                    }
                })?,
        ),
        None => Box::new(io::stdout().lock()),
    };
    serde_json::to_writer(&mut sink, &value).map_err(io_error)?;
    sink.write_all(b"\n")
        .and_then(|_| sink.flush())
        .map_err(io_error)?;
    Ok(code)
}
fn benchmark(
    path: &std::ffi::OsStr,
    signal: &AtomicUsize,
    native: bool,
) -> Result<(i32, Value), Error> {
    let c: simulate::Config =
        serde_json::from_slice(&read(path, 1_048_576)?).map_err(|e| invalid(e.to_string()))?;
    c.validate().map_err(invalid)?;
    if native {
        if c.schema_version != 2 || c.capture.is_some() {
            return Err(invalid(
                "native-rollout-v1 requires schema 2 with capture disabled",
            ));
        }
    } else if c.schema_version != 1 {
        return Err(invalid("scalar-pass-v1 requires legacy pass configuration"));
    }
    if c.episodes > 100 || c.max_decisions > if native { 100_000 } else { 10_000 } {
        return Err(invalid(if native {
            "native benchmark limits: at most 100 episodes and 100000 decisions per episode"
        } else {
            "scalar smoke limits: at most 100 episodes and 10000 decisions per episode"
        }));
    }
    // Includes reset, policy, game work, observations used by simulation, and
    // summary JSON encoding. No terminal rendering occurs in this window.
    let start = Instant::now();
    let mut bytes = Vec::new();
    let control = || {
        stopped(signal).or_else(|| {
            let limit = c.deadline_ms.unwrap_or(10_000).min(10_000);
            (start.elapsed().as_millis() >= limit as u128).then_some(simulate::Stop::Deadline)
        })
    };
    let mut policy_timing = crate::native::PolicyTiming::default();
    let code = if native {
        crate::native::run_instrumented(
            &c,
            &mut bytes,
            control,
            &mut |_, _| Ok(()),
            &mut |_| {},
            Some(&mut policy_timing),
        )
    } else {
        simulate::run(&c, &mut bytes, control, simulate::step)
    }
    .map_err(io_error)?;
    let elapsed = start.elapsed().as_nanos();
    let mut rows = bytes
        .split(|b| *b == b'\n')
        .filter(|b| !b.is_empty())
        .map(serde_json::from_slice::<Value>);
    let run = rows
        .next()
        .ok_or_else(|| io_error("missing run header"))?
        .map_err(io_error)?;
    let summary = rows
        .next_back()
        .ok_or_else(|| io_error("missing summary"))?
        .map_err(io_error)?;
    let mut value = json!({"type":"benchmark","workload":"scalar-pass-v1","qualification":"smoke-only","measurement":"reset-policy-core-and-summary-encoding","elapsed_ns":elapsed,"workers":1,"run":run,"summary":summary,"max_wall_ms":10_000,"os":std::env::consts::OS,"arch":std::env::consts::ARCH,"debug_assertions":cfg!(debug_assertions)});
    if native {
        let episodes = rows.collect::<Result<Vec<_>, _>>().map_err(io_error)?;
        let decisions: u64 = episodes
            .iter()
            .filter_map(|r| r["decisions"].as_u64())
            .sum();
        let work: u64 = episodes
            .iter()
            .filter_map(|r| r["work_calls"].as_u64())
            .sum();
        value["workload"] = json!("native-rollout-v1");
        value["qualification"] = json!("initial-baseline-only");
        value["policy_ns"] = json!(policy_timing.elapsed_ns);
        value["policy_timing"] =
            json!("initialization-and-choice-attempts-excluding-observation-and-submission");
        value["counters"] = json!({"accepted_decisions":decisions,"work_calls":work});
        value["episodes"] = json!(episodes);
    }
    Ok((code, value))
}
fn conformance(
    fixture: &std::ffi::OsStr,
    actual: &std::ffi::OsStr,
    artifacts: &std::ffi::OsStr,
    signal: &AtomicUsize,
) -> Result<(i32, Value), Error> {
    // The comparator is a repository tool, not an engine or a fabricated
    // reference. Its existing strict choice checks and artifacts are retained.
    read(fixture, 1_048_576)?;
    read(actual, 1_048_576)?;
    let script = Path::new(env!("CARGO_MANIFEST_DIR")).join("../../scripts/checkpoints.py");
    if !script.is_file() {
        return Err(io_error("missing repository checkpoint tooling"));
    }
    let mut child = Command::new("python3")
        .arg("-B")
        .arg(script)
        .arg(fixture)
        .arg(actual)
        .arg("--artifacts")
        .arg(artifacts)
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .env_remove("DISPLAY")
        .env_remove("WAYLAND_DISPLAY")
        .spawn()
        .map_err(|e| io_error(format!("python3 checkpoint dependency: {e}")))?;
    let stdout = child.stdout.take().expect("piped stdout");
    let stderr = child.stderr.take().expect("piped stderr");
    fn capture(stream: impl Read) -> io::Result<Vec<u8>> {
        let mut b = Vec::new();
        stream.take(1_048_577).read_to_end(&mut b)?;
        Ok(b)
    }
    let out = thread::spawn(move || capture(stdout));
    let err = thread::spawn(move || capture(stderr));
    let until = Instant::now() + Duration::from_secs(10);
    let status = loop {
        if let Some(s) = child.try_wait().map_err(io_error)? {
            break Ok(s);
        }
        if stopped(signal).is_some() || Instant::now() >= until {
            let _ = child.kill();
            let _ = child.wait();
            break Err((4,"conformance interrupted or timed out after at most 10 seconds; artifacts may be incomplete".into()));
        }
        thread::sleep(Duration::from_millis(5));
    };
    let bytes = out
        .join()
        .map_err(|_| io_error("comparator reader failed"))?
        .map_err(io_error)?;
    let errors = err
        .join()
        .map_err(|_| io_error("comparator reader failed"))?
        .map_err(io_error)?;
    let status = status?;
    if bytes.len() > 1_048_576 || errors.len() > 1_048_576 {
        return Err(io_error("comparator output exceeds byte limit"));
    }
    let mut value: Value = serde_json::from_slice(&bytes).map_err(|_| {
        io_error(
            "checkpoint tooling failed to produce JSON; check repository and Python dependencies",
        )
    })?;
    let code = status.code().unwrap_or(3);
    if code != 0 && code != 1 {
        return Err((
            if code == 2 { 2 } else { 3 },
            format!(
                "invalid conformance input or artifacts: {}",
                value["message"]
            ),
        ));
    }
    if !errors.is_empty()
        || (code == 0 && value["status"] != "pass")
        || (code == 1 && value["status"] != "mismatch")
    {
        return Err(io_error("inconsistent checkpoint comparator result"));
    }
    value["type"] = json!("conformance");
    value["scope"] = json!("supplied-checkpoints-only");
    Ok((code, value))
}

#[cfg(test)]
mod benchmark_tests {
    use super::*;

    #[test]
    fn native_benchmark_preserves_pending_signals_before_first_episode() {
        let path =
            Path::new(env!("CARGO_MANIFEST_DIR")).join("../../fixtures/simulate/native-v2.json");
        for (signal, code, reason) in [
            (signal_hook::consts::SIGTERM, 143, "sigterm"),
            (signal_hook::consts::SIGINT, 130, "sigint"),
        ] {
            let (actual, row) =
                benchmark(path.as_os_str(), &AtomicUsize::new(signal as usize), true).unwrap();
            assert_eq!(actual, code);
            assert_eq!(row["summary"]["reason"], reason);
            assert_eq!(row["summary"]["requested"], 2);
            assert_eq!(row["summary"]["not_started"], 2);
            assert_eq!(row["summary"]["started"], 0);
            assert_eq!(row["summary"]["completed"], 0);
            assert_eq!(row["episodes"], json!([]));
            assert_eq!(row["policy_ns"], 0);
        }
    }
}
