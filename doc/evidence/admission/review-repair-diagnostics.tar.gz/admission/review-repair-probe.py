import json,sys,traceback
from pathlib import Path
sys.path.insert(0,'scripts');import admission_reference as a
r=json.loads(Path('doc/evidence/admission/candidate-v4-run-1-receipt.json').read_text());p=Path('.agent-artifacts')/r['privileged_directory'];doc=json.loads(a.FIXTURE.read_text());ni=json.loads((p/'native-index.json').read_text());xi=json.loads((p/'xmage-index.json').read_text());results={}
for c in doc['cases']:
 try:
  n=json.loads((p/ni[c['id']][0]).read_text());x=json.loads((p/xi[c['id']][0]).read_text());a.compare_game(n,x,c);results[c['id']]='agreed'
 except Exception as error:results[c['id']]=str(error)
print(json.dumps(results,indent=2));Path('.agent-artifacts/admission/review-repair-probe.json').write_text(json.dumps(results,indent=2)+'\n')
if any(v!='agreed' for v in results.values()):raise SystemExit(1)
