import hashlib,json,re,shutil,subprocess
from pathlib import Path
root=Path.cwd();out=root/'doc/evidence/admission';art=root/'.agent-artifacts/admission'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
log=art/'torture-final.log';text=log.read_text();assert re.search(r'Ran 392 tests in .*\n\nOK',text)
rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text)
counts=[sum(int(row[i]) for row in rows) for i in range(3)]
assert counts==[1524,0,0],counts
assert 'Finished `release` profile' in text and 'FAILED' not in text
refs=[json.loads((out/f'run-{n}.json').read_text()) for n in (1,2)]
assert all(r['status']=='agreed' for r in refs) and refs[0]['sources']==refs[1]['sources']
for name,expected in refs[0]['sources'].items():assert sha(root/name)==expected,name
shutil.copyfile(log,out/'torture.log')
validation=dict(schema_version=1,issue=277,base=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip(),
 focused=dict(command="python3 -m unittest discover -s tests -p 'test_m2_repair_admission.py'",tests=22,log='focused.log',sha256=sha(out/'focused.log')),
 python=dict(command='python3 scripts/run_tests.py',tests=392,new_tests=22,execution='final torture checks phase',log='python-discovery.log',sha256=sha(out/'python-discovery.log')),
 cargo=dict(command='cargo test --workspace --locked',executions=762,new_named_tests=3,additional_reused_policy_test=1,failed=0,ignored=0,log='cargo-workspace.log',sha256=sha(out/'cargo-workspace.log')),
 torture=dict(command='python3 "$SYMPHONY_CONTROL_ROOT/scripts/symphony/resource_lock.py" heavy -- ./scripts/torture.sh',python_tests=392,rust_debug_release_executions=1524,failed=0,ignored=0,log='torture.log',sha256=sha(out/'torture.log')),
 reference=dict(command='python3 "$SYMPHONY_CONTROL_ROOT/scripts/symphony/resource_lock.py" heavy -- python3 scripts/full_pool_reference.py --family admission --cache "$MTG_REFERENCE_CACHE" --output .agent-artifacts/admission-run-N.json',invocations=2,distinct_games=16,runs_per_engine_per_invocation=32,invalid_tapes_per_engine=18,comparator_controls=dict(native=42,xmage=43),retained_families=['reset','mulligan','priority','spells','activations','triggers','cleanup','combat'],receipts={f'run-{n}.json':sha(out/f'run-{n}.json') for n in (1,2)},source_files=167,reference_semantics='patched-combat-sba-v1'),
 final_delivery='Separate exact-candidate review, protected PR/merge and exact-main CI are recorded in the issue workpad; this receipt records local executable acceptance only.',
 workpad='https://github.com/pabloxrl/mtg-lab/issues/277#issuecomment-6112473318')
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
print('Final local acceptance: 392 Python tests, 1524 Rust executions, two complete reference invocations.')
