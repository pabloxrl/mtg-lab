#!/usr/bin/env bash
set -euo pipefail
python3 .agent-artifacts/admission/archive-evidence.py generation-attempts admission/heuristic-origins admission/occurrence-origins admission/occurrence-origins-v2
python3 .agent-artifacts/admission/archive-evidence.py diagnostic-native-negatives admission/native-negative-1 admission/native-negative-2
python3 .agent-artifacts/admission/archive-evidence.py diagnostic-xmage admission/xmage-directed-1 admission/xmage-full-1 admission/xmage-full-2 admission/xmage-full-3 admission/xmage-negative-1
python3 .agent-artifacts/admission/archive-evidence.py candidate-v1 admission-run-1.privileged-czxglccb admission/candidate-v1-receipt.json admission/candidate-v1-sources
python3 .agent-artifacts/admission/archive-evidence.py candidate-v2-run-1 admission-run-1.privileged-gz930gbb admission/candidate-v2-run-1-receipt.json admission/candidate-v2-sources
python3 .agent-artifacts/admission/archive-evidence.py candidate-v2-run-2 admission-run-2.privileged-dwn2e5qd admission/candidate-v2-run-2-receipt.json
