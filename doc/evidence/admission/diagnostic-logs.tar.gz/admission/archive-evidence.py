"""Retain completed local attempt artifacts, with restrictive archive modes."""
import gzip,hashlib,json,os,sys,tarfile
from pathlib import Path
root=Path.cwd();source=root/'.agent-artifacts';destination=root/'doc/evidence/admission'
name=sys.argv[1];paths=[source/p for p in sys.argv[2:]]
files=[];dirs=set()
for path in paths:
 if not path.exists():raise ValueError("missing evidence path: "+str(path))
 for p in ([path] if path.is_file() else sorted(path.rglob('*'))):
  if p.is_symlink():raise ValueError('unexpected evidence symlink')
  if p.is_file():
   files.append(p)
   for parent in p.parents:
    if parent==source:break
    dirs.add(parent)
files=sorted(set(files));manifest=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
archive=destination/(name+'.tar.gz')
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w|') as tar:
 for p in sorted(dirs):
  info=tarfile.TarInfo(str(p.relative_to(source)));info.type=tarfile.DIRTYPE;info.mode=0o700;tar.addfile(info)
 for p in files:
  rel=str(p.relative_to(source));before=sha(p);os.chmod(p,0o600)
  info=tar.gettarinfo(str(p),arcname=rel);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o600
  with p.open('rb') as f:tar.addfile(info,f)
  if sha(p)!=before:raise ValueError('active evidence changed: '+rel)
  manifest.append(dict(path=rel,bytes=p.stat().st_size,sha256=before))
(destination/(name+'.json')).write_text(json.dumps(dict(archive=archive.name,sha256=sha(archive),files=manifest),indent=2)+'\n')
print(name,len(manifest),archive.stat().st_size)
