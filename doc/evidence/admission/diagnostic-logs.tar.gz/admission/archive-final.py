import hashlib,json,subprocess,sys
from pathlib import Path
root=Path('.agent-artifacts')
receipts=[json.loads((root/f'admission-run-{n}.json').read_text()) for n in (1,2)]
assert all(r['status']=='agreed' for r in receipts)
assert receipts[0]['sources']==receipts[1]['sources']
for name,sha in receipts[0]['sources'].items():
 assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha,name
 assert hashlib.sha256((root/'admission/final-sources'/name).read_bytes()).hexdigest()==sha,name
for n,r in enumerate(receipts,1):
 paths=[r['privileged_directory'],f'admission-run-{n}.json']
 if n==1:paths.append('admission/final-sources')
 subprocess.run([sys.executable,'.agent-artifacts/admission/archive-evidence.py',f'final-run-{n}',*paths],check=True)
 (Path('doc/evidence/admission')/f'run-{n}.json').write_bytes((root/f'admission-run-{n}.json').read_bytes())
print('Both source-identical complete reference invocations archived.')
