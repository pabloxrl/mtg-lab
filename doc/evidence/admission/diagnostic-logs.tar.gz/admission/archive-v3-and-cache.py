import shutil,subprocess,sys
from pathlib import Path
root=Path.cwd()
assert root.name=='GH-277' and (root/'Cargo.toml').is_file()
cache=root/'target/debug/incremental'
assert not cache.is_symlink()
if cache.exists():shutil.rmtree(cache)
print('Removed only rebuildable checkout-local Cargo incremental cache.',flush=True)
subprocess.run([sys.executable,'.agent-artifacts/admission/archive-evidence.py','candidate-v3','admission-run-1.privileged-4me_rp19','admission/candidate-v3-receipt.json','admission/candidate-v3-sources'],check=True)
