import hashlib,json,subprocess,sys
sys.path.insert(0,'scripts')
from check_program import validate

def read(name,ref='origin/main'):
 return subprocess.check_output(['git','show',f'{ref}:{name}'])
p=read('doc/programs/rfc-0002.json');r=read('doc/programs/rfc-0002-requirements.json');program=json.loads(p);requirements=json.loads(r);source=read(program['rfc'])
validate(program,requirements,source)
assert source==read(program['rfc'],program['source_commit'])
assert set(program['authorized_milestones'])<=set(('M0','M1','M2'))
print(json.dumps(dict(main=subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip(),program=program,program_sha256=hashlib.sha256(p).hexdigest(),requirements_sha256=hashlib.sha256(r).hexdigest(),operator_plan_sha256=hashlib.sha256(read('doc/programs/engine-validation.md')).hexdigest())))
