import hashlib,json
from pathlib import Path
root=Path('doc/evidence/admission')
statuses={
'generation-attempts':('generation-only','Includes missing-occurrence standard captures and both actual occurrence-aware origin versions; none is independently an admission receipt.'),
'diagnostic-native-privileged':('unadmitted-diagnostic','Directed and initial full native attempts, including the preserved first failed full-game prefix.'),
'diagnostic-native-negatives':('unadmitted-diagnostic','Actual invalid-tape attempts; malformed-field rejection cursor failure and repair retained.'),
'diagnostic-xmage':('unadmitted-diagnostic','Directed/full/reference negative attempts and cost-order/trigger-boundary failures retained.'),
'candidate-v1':('superseded-candidate','Passed its then-current verifier; later nested identity controls exposed incomplete checks.'),
'candidate-v2-run-1':('superseded-candidate','Passed its then-current verifier; lacked opening/pre-SBA completeness checks.'),
'candidate-v2-run-2':('superseded-candidate','Repeat of the same sixteen games; not additional distinct games.'),
'candidate-v3':('superseded-candidate','Passed its then-current verifier; missing auxiliary nested identity fields were subsequently reproduced.'),
'final-run-1':('verified-candidate','Final source-bound reference invocation; delivery still requires separate review, protected merge and exact-main CI.'),
'final-run-2':('verified-candidate','Second invocation of the same sixteen games; not additional distinct games.'),
'diagnostic-logs':('retained-diagnostics','Frozen precursor tapes, behavioral reds, first differences, source reconstruction and interrupted/waiting command logs.'),
}
rows=[]
for name,(status,reason) in statuses.items():
 p=root/(name+'.json');m=json.loads(p.read_text());archive=root/m['archive']
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['sha256'],name
 rows.append(dict(manifest=p.name,archive=m['archive'],sha256=m['sha256'],files=len(m['files']),status=status,reason=reason))
(root/'retained-attempts.json').write_text(json.dumps(dict(schema_version=1,distinct_admitted_inputs=16,repeat_policy='Repeated checks of frozen inputs never increase the quota.',attempt_groups=rows),indent=2)+'\n')
