import json,os,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'scripts'))
import xmage
cache=Path(os.environ['MTG_REFERENCE_CACHE']);xmage.verify_inputs(cache)
assert xmage.dependencies(cache)==json.load(open('references/xmage/dependencies.json'))
folder=Path(sys.argv[2]).resolve();folder.mkdir(parents=True,exist_ok=True)
for name in ('FullPoolMulliganTest.java','FullPoolPriorityTest.java','FullPoolTriggersTest.java','FullPoolAdmissionTest.java','CombatSbaGame.java'):
 target=cache/xmage.SOURCE/'Mage.Tests/src/test/java/org/mage/test/mtglab'/name
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((Path('references/xmage')/name).read_bytes())
cmd=xmage.maven(cache)+['-o','-pl','Mage.Tests','-am','test','-Dtest=org.mage.test.mtglab.FullPoolAdmissionTest','-Dsurefire.failIfNoSpecifiedTests=false','-Dmtglab.fixture='+str(Path(sys.argv[1]).resolve()),'-Dmtglab.root='+str(Path.cwd()),'-Dmtglab.output='+str(folder/'xmage-index.json'),'-DargLine=-Djava.awt.headless=true']
xmage.bounded(cmd,cache/xmage.SOURCE,xmage.environment(cache),folder/'xmage.log',600)
