"""Bounded lock holder for a single injected-GitHub-tool transaction."""
import select,sys
print('GH277_HANDOFF_LOCK_READY',flush=True)
ready,_,_=select.select([sys.stdin],[],[],120)
if not ready:
 raise SystemExit('Bounded handoff timed out; no completion assumed')
if sys.stdin.readline().strip()!='release':
 raise SystemExit('Unexpected handoff release token')
print('GH277_HANDOFF_LOCK_RELEASED',flush=True)
