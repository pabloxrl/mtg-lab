Admit sixteen frozen normal-reset native/XMage terminal games: one actual deterministic heuristic origin and one independently authored path for each RG/GR/RR/GG matchup and starting seat. Version 10 requires exact input consumption and intermediate observations, independently authored checkpoints, rules-terminal endings and played witnesses for all twenty nontoken cards. Replay never invokes a policy.

The clients compose the delivered adapters, including the explicitly identified XMage combat patch. Invalid tapes, incomplete auxiliary observations and forged outcomes fail admission. Selected-action acceptance and native rejection checks are distinct from complete legal-set observability, which is not claimed. Every earlier reference family remains exercised. Historical failures, generation attempts and superseded candidate receipts are retained with source hashes and private archive permissions.

Validation results and exact-candidate independent review will be inserted after completion. The root README and reference contract describe the command and its limits. This is the initial two-engine GR-040 subset; it does not complete M2 or the scenario audit and does not qualify Forge or reference-AI generation.

Related to #277. Original owners and #24/#25/#26 acceptance remain unchanged.
