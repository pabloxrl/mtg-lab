"""Recover retained source bytes by reversing edits and checking frozen hashes."""
import json,pathlib,hashlib
root=pathlib.Path.cwd();r=json.loads((root/'.agent-artifacts/admission/candidate-v1-receipt.json').read_text());out=root/'.agent-artifacts/admission/candidate-v1-sources'
for name,sha in r['sources'].items():
 p=out/name
 if p.exists():continue
 s=(root/name).read_text()
 if name.endswith('admission_origin_tests.rs'):
  s=s.replace('    let frozen:Value=serde_json::from_str(include_str!("../../../fixtures/reference/full-pool-admission.json")).unwrap();\n','')
  start=s.index('            let row=format!("GR-040-');end=s.index('            // Replay uses frozen',start);s=s[:start]+s[end:]
 elif name.endswith('admission_reference_tests.rs'):
  s=s.replace('if object {v["source"].is_string()&&v["incarnation"].is_u64()} else {v["source"].is_null()&&v["incarnation"].is_null()}', 'object==v["source"].is_string()&&object==v["incarnation"].is_u64()')
 elif name.endswith('test_m2_repair_admission.py'):
  s=s[:s.index('\n    def test_required_creation_and_stack_provenance')]
 elif name.endswith('admission_observations.py'):
  s=s.replace("DEFINITIONS={c['id']:c for c in json.loads((ROOT/'data/cards/foundations_micro_v1.json').read_text())['cards']}\nCARDS={k:c['characteristics'] for k,c in DEFINITIONS.items()}","CARDS={c['id']:c['characteristics'] for c in json.loads((ROOT/'data/cards/foundations_micro_v1.json').read_text())['cards']}")
  s=s.replace('        identities(p,case,engine,i)\n','');s=s[:s.index('\n\ndef identities(')]
 elif name.endswith('admission_reference.py'):
  start=s.index("        hands=last['hand']");end=s.index('    else:\n        first=semantic',start);s=s[:start]+s[end:]
  start=s.index('    else:\n        require(run.get(\'before_departure\')');end=s.index('\n\ndef compare_game',start)
  s=s[:start]+"    else:require(run.get('before_departure') is not None,'/missing pre-departure state')\n"+s[end:]
  start=s.index('    observed={card:[] for card in manifest');end=s.index('    return observed',start)
  s=s[:start]+'''    for card,witnesses in manifest['played_cards'].items():
        accepted=[]
        for w in witnesses:
            r=runs(w['case']);e=r['consumed_play'][w['sequence']]
            require(e['kind']==w['kind'] and e['source']==w['source'],'/played behavior input witness')
            # Mere deck membership or an uncommitted announcement cannot count.
            resolved=any(w['source'] in p['battlefield'] or any(w['source'] in g for g in p['graveyard']) for p in r['points'][w['sequence']+1:])
            if resolved:accepted.append(w)
        require(accepted,'/unplayed card behavior '+card);observed[card]=accepted
'''+s[end:]
 data=s.encode()
 if hashlib.sha256(data).hexdigest()!=sha:print('hash mismatch',name);continue
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);print('recovered exact bytes',name)
